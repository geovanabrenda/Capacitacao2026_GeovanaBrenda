@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProdutosRepository produtosRepository;

    // ==============================
    // ===== ALTERAÇÃO =====
    // Criar pedido (checkout)
    // ==============================
    public Order criarPedido(Long userId) {

        Cart cart = cartRepository.findByUserIdAndAtivoTrue(userId);

        if (cart == null) {
            throw new RuntimeException("Carrinho não encontrado");
        }

        List<CartItem> itens = cartItemRepository.findAll();

        Order order = new Order();
        order.setUserId(userId);
        order.setStatus(OrderStatus.CREATED);

        order = orderRepository.save(order);

        BigDecimal total = BigDecimal.ZERO;

        for (CartItem item : itens) {

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setProduto(item.getProduto());
            orderItem.setQuantidade(item.getQuantidade());
            orderItem.setPriceSnapshot(item.getPriceSnapshot());

            orderItemRepository.save(orderItem);

            // soma total
            total = total.add(
                    item.getPriceSnapshot().multiply(
                            BigDecimal.valueOf(item.getQuantidade())
                    )
            );

            // ===== ALTERAÇÃO =====
            // baixa estoque
            Produtos produto = item.getProduto();
            produto.setEstoque(produto.getEstoque() - item.getQuantidade());
            produtosRepository.save(produto);
        }

        order.setTotal(total);

        // ===== ALTERAÇÃO =====
        // desativa carrinho
        cart.setAtivo(false);
        cartRepository.save(cart);

        return orderRepository.save(order);
    }

    public Order getById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido não encontrado"));
    }

    // ==============================
    // ===== ALTERAÇÃO =====
    // Cancelar pedido
    // ==============================
    public Order cancelar(Long id) {

        Order order = getById(id);

        if (order.getStatus() != OrderStatus.CREATED &&
                order.getStatus() != OrderStatus.PAID) {

            throw new RuntimeException("Não pode cancelar esse pedido");
        }

        order.setStatus(OrderStatus.CANCELLED);

        return orderRepository.save(order);
    }
}
