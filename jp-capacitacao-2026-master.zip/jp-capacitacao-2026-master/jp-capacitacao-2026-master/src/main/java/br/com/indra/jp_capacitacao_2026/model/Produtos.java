package br.com.indra.jp_capacitacao_2026.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "produtos")
public class Produtos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    private String descricao;

    @Column(nullable = false)
    private BigDecimal preco;

    @Column(name="codigo_barras")
    private String codigoBarras;

    // ==============================
    // ===== ALTERAÇÃO =====
    // Controle de estoque
    // ==============================
    private int estoque;

    // ==============================
    // ===== ALTERAÇÃO =====
    // Produto ativo/inativo
    // ==============================
    private boolean ativo;

    // ==============================
    // ===== ALTERAÇÃO =====
    // Relacionamento com Categoria
    // ==============================
    @ManyToOne
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

}
