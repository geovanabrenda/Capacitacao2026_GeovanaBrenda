@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProdutosRepository produtosRepository;

    // ===== ALTERAÇÃO =====
    // pegar ou criar carrinho ativo
    public Cart getCart(Long userId) {

        Cart cart = cartRepository.findByUserIdAndAtivoTrue(userId);

        if (cart == null) {
            cart = new Cart();
            cart.setUserId(userId);
            cart.setAtivo(true);
            return cartRepository.save(cart);
        }

        return cart;
    }

    // ===== ALTERAÇÃO =====
    // adicionar item
    public CartItem addItem(Long userId, Long produtoId, int quantidade) {

        Cart cart = getCart(userId);

        Produtos produto = produtosRepository.findById(produtoId)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado"));

        // valida estoque
        if (produto.getEstoque() < quantidade) {
            throw new RuntimeException("Estoque insuficiente");
        }

        CartItem item = new CartItem();
        item.setCart(cart);
        item.setProduto(produto);
        item.setQuantidade(quantidade);

        // ===== ALTERAÇÃO =====
        // salvar preço atual
        item.setPriceSnapshot(produto.getPreco());

        return cartItemRepository.save(item);
    }

    // listar itens
    public List<CartItem> getItems(Long userId) {
        Cart cart = getCart(userId);
        return cartItemRepository.findAll();
    }

    // atualizar quantidade
    public CartItem atualizarItem(Long itemId, int quantidade) {

        CartItem item = cartItemRepository.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Item não encontrado"));

        item.setQuantidade(quantidade);

        return cartItemRepository.save(item);
    }

    // remover item
    public void removerItem(Long itemId) {
        cartItemRepository.deleteById(itemId);
    }
}
