package br.com.indra.jp_capacitacao_2026.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class InventoryTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ==============================
    // ===== ALTERAÇÃO =====
    // Produto relacionado
    // ==============================
    @ManyToOne
    private Produtos produto;

    // quantidade (+ ou -)
    private int quantidade;

    // motivo (entrada, venda, ajuste)
    private String motivo;

    private LocalDateTime data = LocalDateTime.now();
}
