package br.com.indra.jp_capacitacao_2026.controller;

import br.com.indra.jp_capacitacao_2026.model.Produtos;
import br.com.indra.jp_capacitacao_2026.repository.ProdutosRepository;
import br.com.indra.jp_capacitacao_2026.service.ProdutosService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequiredArgsConstructor
@Tag(name = "Produtos", description = "Endpoints para gerenciamento de produtos")
@RequestMapping("/produtos")
public class ProdutosController {

    private final ProdutosService produtosService;

    // ==============================
    // C - CREATE
    // ==============================

    @Operation(description = "Endpoint para criar um novo produto",
            summary = "Criação de produto")
    @PostMapping("/cria")
    public ResponseEntity<Produtos> criarProduto(@RequestBody Produtos produto){
        return ResponseEntity.ok(produtosService.createdProduto(produto));
    }

    // ==============================
    // R - READ
    // ==============================

    @GetMapping
    public ResponseEntity<List<Produtos>> getAll(){
        return ResponseEntity.ok(produtosService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Produtos> getById(@PathVariable Long id){
        return ResponseEntity.ok(produtosService.getById(id));
    }

    // ==============================
    // ===== ALTERAÇÃO =====
    // Busca por nome (requisito do trabalho)
    // ==============================
    @GetMapping("/buscar")
    public ResponseEntity<List<Produtos>> buscarPorNome(@RequestParam String nome){
        return ResponseEntity.ok(produtosService.buscarPorNome(nome));
    }

    // ==============================
    // U - UPDATE
    // ==============================

    @PutMapping("/atualiza")
    public ResponseEntity<Produtos> atualizarProduto(@RequestParam Long id,
                                                     @RequestBody Produtos produto){
        return ResponseEntity.ok(produtosService.atualiza(produto));
    }

    @PatchMapping("/atualiza-preco/{id}")
    public ResponseEntity<Produtos> atualizarProdutoParcial(@PathVariable Long id,
                                                            @RequestParam BigDecimal preco) {
        return ResponseEntity.ok(produtosService.atualizaPreco(id, preco));
    }

    // ==============================
    // ===== ALTERAÇÃO =====
    // Controle de estoque (remover)
    // ==============================
    @PostMapping("/estoque/remover/{id}")
    public ResponseEntity<Produtos> removerEstoque(@PathVariable Long id,
                                                   @RequestParam int quantidade) {
        return ResponseEntity.ok(produtosService.removerEstoque(id, quantidade));
    }

    // ==============================
    // ===== ALTERAÇÃO =====
    // Controle de estoque (adicionar)
    // ==============================
    @PostMapping("/estoque/adicionar/{id}")
    public ResponseEntity<Produtos> adicionarEstoque(@PathVariable Long id,
                                                     @RequestParam int quantidade) {
        return ResponseEntity.ok(produtosService.adicionarEstoque(id, quantidade));
    }

    // ==============================
    // D - DELETE
    // ==============================

    @DeleteMapping("/deleta/{id}")
    public ResponseEntity<Void> deletarProduto(@PathVariable Long id) {
        produtosService.deletarProduto(id);
        return ResponseEntity.noContent().build();
    }
}
