@RestController
@RequestMapping("/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;

    // ===== ALTERAÇÃO =====
    // GET /cart
    @GetMapping
    public List<CartItem> getCart(@RequestParam Long userId) {
        return cartService.getItems(userId);
    }

    // ===== ALTERAÇÃO =====
    // POST /cart/items
    @PostMapping("/items")
    public CartItem addItem(@RequestParam Long userId,
                            @RequestParam Long produtoId,
                            @RequestParam int quantidade) {
        return cartService.addItem(userId, produtoId, quantidade);
    }

    // ===== ALTERAÇÃO =====
    // PUT /cart/items/{itemId}
    @PutMapping("/items/{itemId}")
    public CartItem atualizar(@PathVariable Long itemId,
                              @RequestParam int quantidade) {
        return cartService.atualizarItem(itemId, quantidade);
    }

    // ===== ALTERAÇÃO =====
    // DELETE /cart/items/{itemId}
    @DeleteMapping("/items/{itemId}")
    public void remover(@PathVariable Long itemId) {
        cartService.removerItem(itemId);
    }
}
