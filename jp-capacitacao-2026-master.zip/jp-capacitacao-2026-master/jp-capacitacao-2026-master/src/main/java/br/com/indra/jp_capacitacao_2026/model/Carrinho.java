package br.com.indra.jp_capacitacao_2026.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ===== ALTERAÇÃO =====
    // Simulando usuário (simplificado)
    private Long userId;

    // ===== ALTERAÇÃO =====
    // apenas 1 carrinho ativo
    private boolean ativo;

}
